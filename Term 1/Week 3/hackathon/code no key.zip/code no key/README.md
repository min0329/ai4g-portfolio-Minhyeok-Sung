# CommunityConnect

A lightweight Streamlit app that helps people facing social or language barriers find **local community support in The Hague**. It is built around **SDG 10: Reduced Inequalities**.

Statistics Netherlands (CBS) reports that **24% of non-European migrants feel excluded** (CBS 2026). CommunityConnect is a small, practical response: match newcomers to real organisations already working in the city, without letting a language model invent services that do not exist.

## Target audience

- Newcomers and migrants in The Hague who speak limited Dutch
- People who feel isolated, need language practice, food support, or low-threshold social contact
- Volunteers and students who want a simple, explainable matching demo for social inclusion

The app is a prototype for a course/hackathon, not an official municipal service.

## How matching works

To keep API use low and reduce hallucinations:

1. **Python searches locally** in `data/resources.json` using keyword and tag overlap.
2. At most **three** local support records are selected when relevant.
3. Gemini (`gemini-3.6-flash`) uses Google Search grounding to find current Hague-specific options, such as sports clubs, venues, activities, and referral organisations.
4. Search links are shown below the answer so users can verify names, locations, prices, and opening hours.

Empty or very vague input never triggers an API call.

## Setup and run

```bash
pip install streamlit openai python-dotenv
```

Create a `.env` file in the project root (same folder as `app.py`):

```
GEMINI_API_KEY=your_gemini_key_here
```

Get a free key at [https://aistudio.google.com/apikey](https://aistudio.google.com/apikey). Paste it after `=` with no quotes.

Run the app:

```bash
python -m streamlit run app.py
```

Open the local URL Streamlit prints (usually `http://localhost:8501`).

If the API key is missing or the request fails (rate limit, timeout, network), the UI shows:

> AI service temporarily unavailable, showing direct keyword matches below.

Keyword matches from the JSON are still displayed.

## Project structure

```
.
├── app.py                 # Streamlit UI, local matching, guarded LLM explanation
├── data/resources.json    # Curated Hague organisations (source of truth)
└── README.md
```

## Ethical reflection

**Risk.** In social services, a fluent AI answer can look trustworthy even when it is wrong. Hallucinated phone numbers, “free” programmes, or fake NGOs can delay help or put people in unsafe situations.

**Mitigation in this project.**

- The model searches with Google grounding and is instructed to prefer official sources.
- Search sources are displayed so users can verify current information.
- If the API fails, users still see **direct keyword matches** from the curated list.
- Vague queries are rejected locally so tokens are not spent on empty prompts.

This does not remove all risk: tags can miss someone’s real need, and five organisations cannot cover every neighbourhood. A production service would need human review, multilingual UX testing with the communities served, and a clear disclaimer that the tool does not replace professional advice.

## Licence / use

Intended for educational use. Organisation details in `data/resources.json` are simplified public-facing descriptions for demo purposes; always verify current opening hours and eligibility on the official websites.

"""Streamlit entry point for the Inclu community app."""

from app import main


if __name__ == "__main__":
	main()

"""
CommunityConnect — Streamlit app.

Local Python matches the curated support list. Gemini then uses Google Search
grounding to find current Hague-specific information, such as clubs, venues,
activities, and referral options, and returns links for the user to verify.
"""

from __future__ import annotations

import json
import os
import re
import urllib.error
import urllib.request
from pathlib import Path

import streamlit as st
from dotenv import load_dotenv

# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

APP_DIR = Path(__file__).resolve().parent
RESOURCES_PATH = APP_DIR / "data" / "resources.json"
MAX_MATCHES = 3
MIN_QUERY_LENGTH = 8
# Gemini models via the native API, which supports Google Search grounding.
GEMINI_MODEL = "gemini-3.6-flash"
# Use one model per user request to avoid duplicate quota usage.
GEMINI_FALLBACK_MODELS = (GEMINI_MODEL,)
GEMINI_BASE_URL = "https://generativelanguage.googleapis.com/v1beta/openai/"

SYSTEM_PROMPT = (
    "You are a helpful local information assistant for people in The Hague. "
    "Understand the user's actual topic, including hobbies, sports, classes, "
    "food, housing, language, work, and social support. Use Google Search to "
    "find current, relevant options in or near The Hague. The user's selected "
    "hobby or community topic is the main subject: do not replace it with a "
    "generic newcomer or welcome-centre answer. Start by briefly acknowledging "
    "the interest, then recommend concrete clubs, venues, activities, or "
    "organisations that match that topic. Include a short list of the best "
    "options and use the official website links from the search results. Prefer "
    "official websites. Never invent names, addresses, prices, "
    "opening hours, or contact details. Only state facts supported by the "
    "search results or the provided curated records. Mention when the user "
    "should verify availability, membership, or eligibility. Answer in the "
    "same language as the user when possible, in a warm and concise way."
)

# Simple synonym map so everyday phrasing still hits curated tags.
TAG_SYNONYMS = {
    "language": {"language", "dutch", "english", "arabic", "speak", "speaking", "taal"},
    "food": {"food", "hungry", "groceries", "meal", "meals", "voedselbank", "eat"},
    "budget": {"budget", "money", "poor", "poverty", "financial", "cheap", "free", "low-income"},
    "social": {"social", "lonely", "isolated", "friends", "community", "activities", "meet"},
    "women": {"women", "woman", "female", "mother", "mothers"},
    "newcomer": {"new", "newcomer", "migrant", "immigrant", "arrived", "settling", "hague"},
    "integration": {"integration", "inburgering", "permit", "status"},
    "refugee": {"refugee", "asylum", "vluchteling"},
    "legal": {"legal", "lawyer", "asylum", "papers", "documents"},
    "education": {"learn", "learning", "course", "class", "school", "library"},
    "housing": {"housing", "house", "rent", "apartment", "home"},
    "work": {"work", "job", "jobs", "employment"},
    "buddy": {"buddy", "mentor", "volunteer"},
    "family": {"family", "child", "children", "parent", "kids"},
}

TOPIC_OPTIONS = {
    "Badminton & sport": {
        "query": "badminton sports clubs sport halls activities",
        "image": "https://images.unsplash.com/photo-1626224583764-f87db24ac4ea?auto=format&fit=crop&w=800&q=80",
        "description": "Find a club, court, or welcoming activity",
    },
    "Meet people": {
        "query": "social activities meet people community friends",
        "image": "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=800&q=80",
        "description": "Make friends and feel more connected",
    },
    "Language": {
        "query": "language practice Dutch lessons conversation groups",
        "image": "https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=800&q=80",
        "description": "Practise Dutch or find a language group",
    },
    "Food & budget": {
        "query": "food bank free groceries low-cost food financial support",
        "image": "https://images.unsplash.com/photo-1488459716781-31db52582fe9?auto=format&fit=crop&w=800&q=80",
        "description": "Find affordable food and practical help",
    },
    "Housing": {
        "query": "housing rental home accommodation support",
        "image": "https://images.unsplash.com/photo-1560185008-b033106af5c3?auto=format&fit=crop&w=800&q=80",
        "description": "Get help finding a safe place to live",
    },
    "New in The Hague": {
        "query": "newcomer integration welcome centre local support",
        "image": "https://images.unsplash.com/photo-1523731407965-2430cd12f5e4?auto=format&fit=crop&w=800&q=80",
        "description": "Settle in and discover your new city",
    },
}

HOBBY_OPTIONS = {
    "Badminton": {
        "query": "badminton clubs courts sport halls",
        "image": TOPIC_OPTIONS["Badminton & sport"]["image"],
        "description": "Play, practise, and meet local players",
    },
    "Football": {
        "query": "football clubs amateur teams pitches",
        "image": "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=800&q=80",
        "description": "Find a team or casual game",
    },
    "Dance": {
        "query": "dance classes dance communities studios",
        "image": "https://images.unsplash.com/photo-1504609813442-a8924e83f76e?auto=format&fit=crop&w=800&q=80",
        "description": "Move, learn, and meet people",
    },
    "Music": {
        "query": "music groups choirs jam sessions communities",
        "image": "https://images.unsplash.com/photo-1516280440614-37939bbacd81?auto=format&fit=crop&w=800&q=80",
        "description": "Find your sound and your people",
    },
    "Creative making": {
        "query": "creative workshops art maker communities",
        "image": "https://images.unsplash.com/photo-1513364776144-60967b0f800f?auto=format&fit=crop&w=800&q=80",
        "description": "Make things together",
    },
    "Games & gaming": {
        "query": "board game groups gaming communities events",
        "image": "https://images.unsplash.com/photo-1610890716171-6b1bb98ffd09?auto=format&fit=crop&w=800&q=80",
        "description": "Find a friendly table or event",
    },
}

AGE_OPTIONS = {
    "Under 18": "I am under 18",
    "18 - 24": "I am between 18 and 24",
    "25 - 34": "I am between 25 and 34",
    "35 - 54": "I am between 35 and 54",
    "55+": "I am 55 or older",
}

CATEGORY_DATA = {
    "Sport": {
        "image": "https://images.unsplash.com/photo-1461896836934-ffe607ba8211?auto=format&fit=crop&w=1000&q=80",
        "description": "Move your body and meet people through play.",
        "items": {
            "Football": {
                "image": "https://images.unsplash.com/photo-1579952363873-27f3bade9f55?auto=format&fit=crop&w=800&q=80",
                "description": "Join a team, training, or casual game.",
                "query": "football clubs amateur teams pitches communities in The Hague",
                "guide": ["Choose a club and check its beginner or trial-training page.", "Send a short message in English or Dutch asking about age group, level, and trial sessions.", "Bring sports clothes and arrive early; ask a teammate to translate if needed.", "Register only after you know the fees, schedule, and membership conditions."],
                "links": [("KNVB", "https://www.knvb.nl/")],
            },
            "Basketball": {
                "image": "https://images.unsplash.com/photo-1546519638-68e109498ffc?auto=format&fit=crop&w=800&q=80",
                "description": "Find a court, team, or open basketball session.",
                "query": "basketball clubs courts open sessions communities in The Hague",
                "guide": ["Look for a nearby club or public court and check the training times.", "Ask whether beginners can try one session before registering.", "Use a translation app for the registration form or ask the club for English help.", "Confirm equipment, costs, and the age group before joining."],
                "links": [("Basketball Netherlands", "https://www.basketball.nl/")],
            },
            "Tennis": {
                "image": "https://images.unsplash.com/photo-1554068865-24cecd4e34b8?auto=format&fit=crop&w=800&q=80",
                "description": "Play socially or start with beginner lessons.",
                "query": "tennis clubs beginner lessons courts communities in The Hague",
                "guide": ["Compare clubs by location, lesson level, and indoor or outdoor courts.", "Ask for a beginner lesson or social tennis session.", "Check whether a racket can be borrowed and what the trial price is.", "Complete membership only when the schedule and costs work for you."],
                "links": [("Tennis Netherlands", "https://www.tennis.nl/")],
            },
        },
    },
    "Party": {
        "image": "https://images.unsplash.com/photo-1492684223066-81342ee5ff30?auto=format&fit=crop&w=1000&q=80",
        "description": "Find welcoming events, nightlife, and cultural gatherings.",
        "items": {
            "Community events": {
                "image": "https://images.unsplash.com/photo-1501386761578-eac5c94b800a?auto=format&fit=crop&w=800&q=80",
                "description": "Low-pressure events where it is easy to meet people.",
                "query": "community events social gatherings newcomers in The Hague",
                "guide": ["Pick an event with a clear date, location, and organiser.", "Check whether it is free, accessible, and suitable for your age group.", "Message the organiser if you need language or accessibility support.", "Arrive early and use the welcome desk or host to meet your first person."],
                "links": [("The Hague events", "https://www.denhaag.com/en")],
            },
            "Music & nightlife": {
                "image": "https://images.unsplash.com/photo-1514525253161-7a46d19cd819?auto=format&fit=crop&w=800&q=80",
                "description": "Discover concerts, DJs, and live music with others.",
                "query": "live music concerts nightlife communities events in The Hague",
                "guide": ["Check the venue calendar and age requirements.", "Look for group-friendly or free events if you are going alone.", "Buy tickets only through the official venue page.", "Save the venue address and return-travel plan before you go."],
                "links": [("Paard programme", "https://www.paard.nl/en/event/")],
            },
        },
    },
    "Dutch Language": {
        "image": "https://images.unsplash.com/photo-1457369804613-52c61a468e7d?auto=format&fit=crop&w=1000&q=80",
        "description": "Practise Dutch in relaxed groups and classes.",
        "items": {
            "Conversation groups": {
                "image": "https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=800&q=80",
                "description": "Talk, listen, and meet people at your level.",
                "query": "Dutch conversation groups language cafes newcomers in The Hague",
                "guide": ["Choose a conversation group with a beginner-friendly level.", "Check whether you need to register or can walk in.", "Tell the host which language support you need; many groups welcome English speakers.", "Attend regularly so the group can learn your level and interests."],
                "links": [("Bibliotheek Den Haag activities", "https://www.bibliotheekdenhaag.nl/activiteiten.html")],
            },
            "Dutch courses": {
                "image": "https://images.unsplash.com/photo-1509062522246-3755977927d7?auto=format&fit=crop&w=800&q=80",
                "description": "Find structured lessons and language support.",
                "query": "Dutch language courses beginners newcomers in The Hague",
                "guide": ["Take a level test or explain your current level to the provider.", "Ask about free, municipal, evening, and childcare options.", "Request an English explanation of the registration and payment steps.", "Keep your confirmation email and ask what to bring to the first lesson."],
                "links": [("The Hague municipality integration", "https://www.denhaag.nl/en/integration-and-naturalisation.htm")],
            },
        },
    },
    "Study / Academic": {
        "image": "https://images.unsplash.com/photo-1523240795612-9a054b0db644?auto=format&fit=crop&w=1000&q=80",
        "description": "Study together, find mentorship, and build your network.",
        "items": {
            "Study groups": {
                "image": "https://images.unsplash.com/photo-1522202176988-66273c2fd55f?auto=format&fit=crop&w=800&q=80",
                "description": "Find peers for focus, accountability, and friendship.",
                "query": "study groups student communities libraries in The Hague",
                "guide": ["Choose a library, student group, or subject-based community.", "Check whether you need a student card or can join as a visitor.", "Introduce yourself with your subject and preferred study language.", "Agree on quiet hours, breaks, and how to stay in touch."],
                "links": [("Bibliotheek Den Haag libraries", "https://www.bibliotheekdenhaag.nl/bibliotheken.html")],
            },
            "Mentoring": {
                "image": "https://images.unsplash.com/photo-1544717305-2782549b5136?auto=format&fit=crop&w=800&q=80",
                "description": "Get guidance from someone with relevant experience.",
                "query": "student mentoring academic support newcomers in The Hague",
                "guide": ["Write down what you want help with: study choice, language, exams, or career.", "Check the mentor's background and the programme's privacy information.", "Ask whether meetings can happen in English or another language.", "Set one small goal for the first meeting and review it together."],
                "links": [("The Hague University", "https://www.thuas.com/")],
            },
        },
    },
    "Volunteering": {
        "image": "https://images.unsplash.com/photo-1559027615-cd4628902d4a?auto=format&fit=crop&w=1000&q=80",
        "description": "Give your time, learn skills, and become part of a local team.",
        "items": {
            "Community volunteering": {
                "image": "https://images.unsplash.com/photo-1559027615-cd4628902d4a?auto=format&fit=crop&w=800&q=80",
                "description": "Support neighbours, events, or local organisations.",
                "query": "community volunteering opportunities newcomers in The Hague",
                "guide": ["Choose a cause that feels meaningful and realistic for your schedule.", "Read the role description and check language, age, and background requirements.", "Ask the coordinator to explain the role in simple English or Dutch.", "Start with one shift, then decide whether the team feels right for you."],
                "links": [("Volunteer opportunities", "https://www.volunteerthehague.nl/volunteer/opportunities")],
            },
            "Youth volunteering": {
                "image": "https://images.unsplash.com/photo-1504150558240-0b4fd8946624?auto=format&fit=crop&w=800&q=80",
                "description": "Build experience while helping your neighbourhood.",
                "query": "youth volunteering opportunities community in The Hague",
                "guide": ["Check the minimum age and whether supervision is provided.", "Choose a short project if you are trying volunteering for the first time.", "Ask what training and support you receive before starting.", "Request a reference or participation certificate when you finish."],
                "links": [("Volunteer talent scan", "https://www.volunteerthehague.nl/talentscan")],
            },
        },
    },
}

# Extra curated starting points keep each category useful even without AI.
CATEGORY_DATA["Sport"]["items"].update({
    "Running": {"image": "https://images.unsplash.com/photo-1552674605-db6ffd4facb5?auto=format&fit=crop&w=800&q=80", "description": "Run with a group at an easy or ambitious pace.", "query": "running clubs running groups communities in The Hague", "guide": ["Choose a group whose pace and meeting point suit you.", "Ask whether the first run is free and whether beginners are welcome.", "Tell the organiser your language and running experience.", "Join once before deciding on a regular membership."], "links": [("Find an athletics or running club", "https://www.atletiekunie.nl/clubs/")]},
    "Volleyball": {"image": "https://images.unsplash.com/photo-1612872087720-bb876e2e67d1?auto=format&fit=crop&w=800&q=80", "description": "Find indoor teams, beach volleyball, and open play.", "query": "volleyball clubs open play communities in The Hague", "guide": ["Look for a club with a beginner or recreational team.", "Ask about a trial training and equipment.", "Request an English explanation of membership and fees.", "Bring sports clothes and arrive early to meet the captain."], "links": [("Nevobo volleyball", "https://www.nevobo.nl/")]},
})
CATEGORY_DATA["Party"]["items"].update({
    "Cultural festivals": {"image": "https://images.unsplash.com/photo-1533174072545-7a4b6ad7a6c3?auto=format&fit=crop&w=800&q=80", "description": "Celebrate music, food, and culture across the city.", "query": "cultural festivals international community events in The Hague", "guide": ["Check the official event page for date, location, and entrance rules.", "Look for volunteer hosts or international programme information.", "Ask the organiser about language and accessibility support.", "Share the event with a friend or use the welcome point to meet people."], "links": [("The Hague events", "https://www.denhaag.com/en"), ("The Hague city events", "https://www.denhaag.nl/en/events.htm")]},
    "Arts & theatre": {"image": "https://images.unsplash.com/photo-1503095396549-807759245b35?auto=format&fit=crop&w=800&q=80", "description": "See performances and meet audiences around the city.", "query": "arts theatre cultural communities events in The Hague", "guide": ["Choose a performance with information in a language you understand.", "Check reduced-price, student, or community tickets.", "Contact the venue if you need help before booking.", "Use the foyer or introduction programme as an easy conversation starter."], "links": [("HNT theatre", "https://www.hnt.nl/")]},
})
CATEGORY_DATA["Dutch Language"]["items"].update({
    "Language exchange": {"image": "https://images.unsplash.com/photo-1521737711867-e3b97375f902?auto=format&fit=crop&w=800&q=80", "description": "Practise Dutch while helping someone with your language.", "query": "Dutch language exchange groups communities in The Hague", "guide": ["Choose a group with clear beginner and intermediate levels.", "Say which languages you speak and what you want to practise.", "Agree on a simple Dutch-English conversation rhythm.", "Meet in a public place and decide together whether to continue."], "links": [("Bibliotheek Den Haag activities", "https://www.bibliotheekdenhaag.nl/activiteiten.html")]},
    "Reading & writing": {"image": "https://images.unsplash.com/photo-1524995997946-a1c2e315a42f?auto=format&fit=crop&w=800&q=80", "description": "Build confidence with books, reading circles, and writing.", "query": "Dutch reading writing groups language communities in The Hague", "guide": ["Ask the library which group matches your level.", "You do not need perfect Dutch; explain what support you need.", "Bring a library card if the group requests one.", "Attend regularly and ask about other free language activities."], "links": [("Bibliotheek Den Haag", "https://www.bibliotheekdenhaag.nl/")]},
})
CATEGORY_DATA["Study / Academic"]["items"].update({
    "Career networking": {"image": "https://images.unsplash.com/photo-1556761175-b413da4baf72?auto=format&fit=crop&w=800&q=80", "description": "Meet students and professionals who can open doors.", "query": "career networking student communities events in The Hague", "guide": ["Choose an event related to your study or career interest.", "Prepare a two-sentence introduction in your preferred language.", "Ask organisers whether newcomers can attend without experience.", "Follow up with one person and ask for a short informational chat."], "links": [("The Hague municipality", "https://www.denhaag.nl/en/")]},
    "Libraries & quiet study": {"image": "https://images.unsplash.com/photo-1568667256549-094345857637?auto=format&fit=crop&w=800&q=80", "description": "Find welcoming places to focus and study together.", "query": "libraries quiet study spaces student communities in The Hague", "guide": ["Check opening hours and whether a library card is needed.", "Choose a branch close to home or public transport.", "Ask staff for quiet rooms, computers, or language resources.", "Use the noticeboard to find study groups and workshops."], "links": [("Bibliotheek Den Haag", "https://www.bibliotheekdenhaag.nl/")]},
})
CATEGORY_DATA["Volunteering"]["items"].update({
    "Environment & animals": {"image": "https://images.unsplash.com/photo-1559027615-cd4628902d4a?auto=format&fit=crop&w=800&q=80", "description": "Care for green spaces, animals, and the neighbourhood.", "query": "environment animal volunteering opportunities in The Hague", "guide": ["Choose a project with a clear role and supervisor.", "Check age, language, physical, and background requirements.", "Ask whether training and materials are provided.", "Start with a one-day activity before committing longer term."], "links": [("Volunteer opportunities", "https://www.volunteerthehague.nl/volunteer/opportunities")]},
    "Events & culture": {"image": "https://images.unsplash.com/photo-1559027615-cd4628902d4a?auto=format&fit=crop&w=800&q=80", "description": "Help organise events and welcome people into the city.", "query": "events culture volunteer opportunities communities in The Hague", "guide": ["Read the role description and shift times carefully.", "Ask for a coordinator who can explain tasks in simple language.", "Confirm travel, meals, insurance, and age requirements.", "Request feedback and a participation certificate after your first project."], "links": [("Volunteer events", "https://www.volunteerthehague.nl/events")]},
})

UI_TEXT = {
    "English": {"home": "Home", "language": "Language", "motto": "Find your place and feel included.", "hero_text": "Discover welcoming communities, activities, and support in The Hague.", "looking": "What are you looking for?", "explore": "Explore", "personal": "Get a personal recommendation", "not_sure": "Not sure where to start?", "guide": "How to join", "links": "Useful starting links", "ai": "Find more current options with AI", "back": "Back", "form_title": "Find a community that fits you", "interest": "What are you interested in?", "find": "Find my communities", "suggestions": "Your community suggestions", "links_explore": "Links to explore"},
    "Dutch": {"home": "Home", "language": "Taal", "motto": "Vind jouw plek en voel je welkom.", "hero_text": "Ontdek gastvrije communities, activiteiten en hulp in Den Haag.", "looking": "Waar ben je naar op zoek?", "explore": "Bekijk", "personal": "Persoonlijk advies", "not_sure": "Weet je niet waar je moet beginnen?", "guide": "Zo doe je mee", "links": "Handige links", "ai": "Vind meer actuele opties met AI", "back": "Terug", "form_title": "Vind een community die bij je past", "interest": "Waar ben je in geïnteresseerd?", "find": "Vind mijn communities", "suggestions": "Jouw communitysuggesties", "links_explore": "Links om te bekijken"},
    "Spanish": {"home": "Inicio", "language": "Idioma", "motto": "Encuentra tu lugar y siéntete incluido.", "hero_text": "Descubre comunidades, actividades y apoyo en La Haya.", "looking": "¿Qué estás buscando?", "explore": "Explorar", "personal": "Recomendación personal", "not_sure": "¿No sabes por dónde empezar?", "guide": "Cómo participar", "links": "Enlaces útiles", "ai": "Buscar más opciones actuales con IA", "back": "Volver", "form_title": "Encuentra una comunidad para ti", "interest": "¿Qué te interesa?", "find": "Buscar mis comunidades", "suggestions": "Tus sugerencias", "links_explore": "Enlaces para explorar"},
}

# Reload .env on every run so a newly pasted key is picked up after Streamlit rerun.
load_dotenv(APP_DIR / ".env", override=True)


# ---------------------------------------------------------------------------
# Data loading
# ---------------------------------------------------------------------------

def load_resources(path: Path = RESOURCES_PATH) -> list[dict]:
    """Load curated community organisations from JSON."""
    with path.open(encoding="utf-8") as handle:
        return json.load(handle)


# ---------------------------------------------------------------------------
# Local keyword / tag matching (no LLM)
# ---------------------------------------------------------------------------

def tokenize(text: str) -> set[str]:
    """Lowercase word tokens, dropping very short fragments."""
    return {token for token in re.findall(r"[a-zA-ZÀ-ÿ]+", text.lower()) if len(token) >= 2}


def expand_query_tokens(tokens: set[str]) -> set[str]:
    """Add curated tag labels when the user's words overlap a synonym set."""
    expanded = set(tokens)
    for tag, synonyms in TAG_SYNONYMS.items():
        if tokens & synonyms:
            expanded.add(tag)
    return expanded


def score_resource(resource: dict, query_tokens: set[str], preferred_language: str) -> int:
    """
    Score one organisation by keyword overlap with tags, name, description,
    and supported languages. Prefer resources that list the selected language.
    """
    tag_tokens = {tag.lower() for tag in resource.get("tags", [])}
    language_tokens = {lang.lower() for lang in resource.get("languages", [])}
    text_tokens = tokenize(
        f"{resource.get('name', '')} {resource.get('description', '')} {resource.get('location', '')}"
    )

    overlap_tags = query_tokens & tag_tokens
    overlap_text = query_tokens & text_tokens
    overlap_lang = query_tokens & language_tokens

    score = (3 * len(overlap_tags)) + len(overlap_text) + (2 * len(overlap_lang))

    if preferred_language and preferred_language.lower() in language_tokens:
        score += 2

    return score


def match_resources(
    resources: list[dict],
    user_text: str,
    preferred_language: str,
    limit: int = MAX_MATCHES,
) -> list[dict]:
    """Return up to `limit` resources ranked by local keyword overlap."""
    query_tokens = expand_query_tokens(tokenize(user_text))
    if preferred_language:
        query_tokens.add(preferred_language.lower())

    ranked: list[tuple[int, dict]] = []
    for resource in resources:
        points = score_resource(resource, query_tokens, preferred_language)
        if points > 0:
            ranked.append((points, resource))

    ranked.sort(key=lambda item: item[0], reverse=True)
    return [resource for _, resource in ranked[:limit]]


def is_query_too_vague(user_text: str) -> bool:
    """Skip API calls for empty or near-empty input."""
    cleaned = user_text.strip()
    return len(cleaned) < MIN_QUERY_LENGTH or not tokenize(cleaned)


# ---------------------------------------------------------------------------
# LLM explanation (formatting only; matches are already chosen in Python)
# ---------------------------------------------------------------------------

def build_user_prompt(user_text: str, matches: list[dict]) -> str:
    """Pass only the user's scenario and the already-matched JSON objects."""
    payload = {
        "user_situation": user_text.strip(),
        "matched_organizations": matches,
    }
    return (
        "User situation:\n"
        f"{user_text.strip()}\n\n"
        "Matched organizations (JSON — do not add or change facts):\n"
        f"{json.dumps(payload['matched_organizations'], ensure_ascii=False, indent=2)}"
    )


def _llm_client_config() -> tuple[str, str, str] | None:
    """Return (api_key, base_url, model) for Gemini, or None if no key is set."""
    gemini_key = os.getenv("GEMINI_API_KEY", "").strip()
    if gemini_key:
        return gemini_key, GEMINI_BASE_URL, GEMINI_MODEL
    return None


def explain_matches(
    user_text: str, matches: list[dict]
) -> tuple[str | None, str | None, list[dict]]:
    """
    Ask Gemini to search the web and explain relevant local options.

    Returns (explanation, error_message, sources). Search results are returned
    separately so the UI can expose the links used by the answer.
    """
    config = _llm_client_config()
    if not config:
        return None, "missing_api_key", []

    api_key, _base_url, preferred_model = config

    try:
        prompt = (
            f"User request: {user_text.strip()}\n\n"
            "The web search is the primary source for this answer. Search specifically "
            "for clubs, communities, venues, and recurring activities matching the "
            "selected hobby in The Hague. Use the curated records only as secondary "
            "context, never as a replacement for the hobby search.\n"
            f"{json.dumps(matches, ensure_ascii=False, indent=2)}"
        )
        request_body = {
            "system_instruction": {"parts": [{"text": SYSTEM_PROMPT}]},
            "contents": [{"role": "user", "parts": [{"text": prompt}]}],
            "tools": [{"google_search": {}}],
            "generationConfig": {"temperature": 0.2, "maxOutputTokens": 1024},
        }

        last_error = "api_error"
        for model in GEMINI_FALLBACK_MODELS:
            try:
                endpoint = (
                    "https://generativelanguage.googleapis.com/v1beta/"
                    f"models/{model}:generateContent?key={api_key}"
                )
                request = urllib.request.Request(
                    endpoint,
                    data=json.dumps(request_body).encode("utf-8"),
                    headers={"Content-Type": "application/json"},
                    method="POST",
                )
                with urllib.request.urlopen(request, timeout=45) as response:
                    payload = json.loads(response.read().decode("utf-8"))

                candidates = payload.get("candidates", [])
                parts = candidates[0].get("content", {}).get("parts", []) if candidates else []
                text = "\n".join(
                    part.get("text", "") for part in parts if part.get("text")
                ).strip()
                if text:
                    metadata = candidates[0].get("groundingMetadata", {})
                    sources = [
                        {
                            "title": chunk.get("web", {}).get("title", "Web source"),
                            "uri": chunk.get("web", {}).get("uri", ""),
                        }
                        for chunk in metadata.get("groundingChunks", [])
                        if chunk.get("web", {}).get("uri")
                    ]
                    return text, None, sources
                last_error = "empty_response"
            except urllib.error.HTTPError as error:
                if error.code == 429:
                    last_error = "search_quota_exceeded"
                elif error.code == 503:
                    last_error = "service_overloaded"
                else:
                    last_error = "api_error"
                continue
            except (OSError, ValueError, KeyError):
                last_error = "api_error"
                continue
        return None, last_error, []
    except Exception:
        # Network, rate limit, auth, timeout, SDK errors — all share one UI path.
        return None, "api_error", []


# ---------------------------------------------------------------------------
# Streamlit UI
# ---------------------------------------------------------------------------

def render_resource_card(resource: dict) -> None:
    """Show official name, contact, and source fields from JSON only."""
    languages = ", ".join(resource.get("languages", []))
    tags = ", ".join(resource.get("tags", []))

    with st.container(border=True):
        st.subheader(resource.get("name", "Unknown organisation"))
        st.write(resource.get("description", ""))
        st.markdown(f"**Contact:** {resource.get('contact', 'See organisation website')}")
        st.markdown(f"**Location:** {resource.get('location', 'The Hague')}")
        st.caption(f"Languages: {languages} · Tags: {tags} · Source id: {resource.get('id', 'n/a')}")


def build_profile_query(
    topic: str,
    age: int,
    preferred_language: str,
    neighbourhood: str,
    goals: list[str],
    newcomer_status: str,
) -> str:
    """Turn the visual profile choices into one focused search request."""
    query_parts = [f"{TOPIC_OPTIONS[topic]['query']} in The Hague"]
    if age:
        query_parts.append(f"I am {age} years old")
    if preferred_language:
        query_parts.append(f"support in {preferred_language}")
    if neighbourhood != "Anywhere in The Hague":
        query_parts.append(f"near {neighbourhood}")
    if goals:
        query_parts.append("I want " + ", ".join(goals).lower())
    if newcomer_status == "I recently arrived here":
        query_parts.append("I am a newcomer")
    return ". ".join(query_parts) + "."


def render_image_choice(label: str, details: dict, choice_type: str) -> bool:
    """Render an image with a same-page Streamlit selection button."""
    st.image(details["image"], use_container_width=True)
    st.markdown(
        f"<strong>{label}</strong><br><small>{details['description']}</small>",
        unsafe_allow_html=True,
    )
    return st.button(
        f"Choose {label}",
        key=f"{choice_type}_{label}",
        use_container_width=True,
    )


def reset_wizard() -> None:
    """Start a fresh profile without carrying old choices into the next search."""
    st.session_state.pop("profile", None)
    st.session_state.wizard_step = 0
    st.rerun()


def render_category_card(category: str, details: dict) -> bool:
    """Render a clickable category card on the landing page."""
    ui = UI_TEXT[st.session_state.get("language", "English")]
    st.image(details["image"], use_container_width=True)
    st.markdown(f"**{category}**<br><small>{details['description']}</small>", unsafe_allow_html=True)
    return st.button(ui["explore"], key=f"category_{category}", use_container_width=True)


def render_subcategory_card(category: str, name: str, details: dict) -> bool:
    """Render a clickable subcategory card."""
    ui = UI_TEXT[st.session_state.get("language", "English")]
    st.image(details["image"], use_container_width=True)
    st.markdown(f"**{name}**<br><small>{details['description']}</small>", unsafe_allow_html=True)
    return st.button(ui["guide"], key=f"subcategory_{category}_{name}", use_container_width=True)


def render_guide(item: dict) -> None:
    """Show practical, language-friendly joining instructions."""
    language = st.session_state.get("language", "English")
    ui = UI_TEXT[language]
    st.subheader(ui["guide"])
    st.write(item["description"] + " Check the official link below for current dates, costs, and availability.")
    for number, step in enumerate(item["guide"], start=1):
        st.markdown(f"**{number}.** {step}")
    st.subheader(ui["links"])
    for title, url in item["links"]:
        st.markdown(f"[{title}]({url})")


def main() -> None:
    st.set_page_config(page_title="Inclu", page_icon="🤝", layout="wide")
    st.markdown(
        """
        <style>
        :root { --inclu-orange: #db4a2b; --inclu-paper: #e4e2dd; --inclu-ink: #2b2b2b;
                --inclu-muted: #716d68; --inclu-line: #c9c5bf; }
        .stApp { background: var(--inclu-paper); color: var(--inclu-ink); }
        .block-container { max-width: 1180px; padding: 1.15rem 2rem 4rem; }
        header[data-testid="stHeader"] { background: var(--inclu-paper); }
        .topbar { display: flex; align-items: center; padding: .45rem 0 1.25rem;
              border-bottom: 2px solid var(--inclu-ink); }
        .brand { color: var(--inclu-orange); font-size: 2rem; font-weight: 900; letter-spacing: -.07em; }
        .eyebrow { color: var(--inclu-orange); font-size: .76rem; font-weight: 800;
                   letter-spacing: .12em; text-transform: uppercase; }
        [data-testid="stImage"] img { object-fit: cover; border-radius: 0; filter: saturate(.88); }
        [data-testid="stButton"] button { min-height: 2.7rem; border: 2px solid var(--inclu-ink);
            border-radius: 0; background: transparent; color: var(--inclu-ink); font-weight: 800; }
        [data-testid="stButton"] button:hover { background: var(--inclu-orange); color: var(--inclu-paper); border-color: var(--inclu-orange); }
        [data-testid="stFormSubmitButton"] button { min-height: 3rem; border-radius: 0;
            background: var(--inclu-orange); color: var(--inclu-paper); border-color: var(--inclu-orange); }
        .hero { padding: 3rem 0 2.5rem; border-bottom: 2px solid var(--inclu-ink); }
        .hero h1 { color: var(--inclu-ink); font-size: clamp(2.5rem, 6vw, 6.2rem); line-height: .9; margin: .6rem 0 1.2rem; letter-spacing: -.07em; max-width: 900px; }
        .hero p { max-width: 42rem; color: var(--inclu-ink); font-size: 1.15rem; }
        .recommendation-copy { padding: 1.5rem 0 .5rem; }
        .recommendation-copy h2 { color: var(--inclu-orange); font-size: clamp(2rem, 4vw, 3.8rem); line-height: .95; letter-spacing: -.05em; margin: .35rem 0 .75rem; }
        .recommendation-copy p { max-width: 42rem; font-size: 1.15rem; }
        .recommendation-image img { height: auto !important; max-height: none !important; object-fit: contain; }
        .guide { padding: 1.25rem 1.4rem; border-left: 5px solid var(--inclu-orange); background: #d7d4ce; }
        [data-testid="stVerticalBlock"] h1, [data-testid="stVerticalBlock"] h2, [data-testid="stVerticalBlock"] h3,
        [data-testid="stVerticalBlock"] p, [data-testid="stVerticalBlock"] label { color: var(--inclu-ink); }
        [data-testid="stCaptionContainer"] p { color: var(--inclu-muted); }
        [data-baseweb="select"] > div, [data-baseweb="input"] > div, textarea { border-radius: 0 !important;
            border: 2px solid var(--inclu-ink) !important; background: var(--inclu-paper) !important; color: var(--inclu-ink) !important; }
        [data-testid="stAlert"] { border-radius: 0; border-left-color: var(--inclu-orange); background: #d7d4ce; }
        a { color: var(--inclu-orange) !important; font-weight: 700; }
        @media (max-width: 700px) { .block-container { padding: 1rem 1rem 3rem; }
            .hero { padding: 2.5rem 0 2rem; } .hero h1 { font-size: 3.6rem; } }
        </style>
        """,
        unsafe_allow_html=True,
    )
    st.session_state.setdefault("page", "landing")
    st.session_state.setdefault("selected_category", None)
    st.session_state.setdefault("selected_item", None)
    st.session_state.setdefault("language", "English")
    top_left, top_right = st.columns([5, 1])
    with top_left:
        st.markdown('<div class="topbar"><span class="brand">Inclu</span></div>', unsafe_allow_html=True)
    with top_right:
        st.session_state.language = st.selectbox(
            "Language",
            ["English", "Dutch", "Spanish"],
            index=["English", "Dutch", "Spanish"].index(st.session_state.language),
            label_visibility="collapsed",
        )
    ui = UI_TEXT[st.session_state.language]
    page = st.session_state.page
    st.caption(ui["motto"])

    if page == "landing":
        st.markdown(f'<div class="hero"><div class="eyebrow">YOUR LOCAL STARTING POINT</div><h1>Find your place and feel included.</h1><p>{ui["hero_text"]}</p></div>', unsafe_allow_html=True)
        recommendation_image, recommendation_copy = st.columns([1.15, 1], gap="large")
        with recommendation_image:
            st.markdown('<div class="recommendation-image">', unsafe_allow_html=True)
            st.image("https://images.unsplash.com/photo-1529156069898-49953e39b3ac?auto=format&fit=crop&w=1200&q=85", use_container_width=True)
            st.markdown('</div>', unsafe_allow_html=True)
        with recommendation_copy:
            st.markdown('<div class="recommendation-copy"><div class="eyebrow">PERSONAL COMMUNITY MATCH</div><h2>Start with you.</h2><p>Tell us what you enjoy, what you need, and where you feel comfortable. Inclu finds communities and real next steps that fit your life.</p></div>', unsafe_allow_html=True)
            if st.button(ui["personal"], type="primary", key="hero_personal_recommendation"):
                st.session_state.page = "form"
                st.rerun()
        st.divider()
        st.subheader(ui["looking"])
        category_columns = st.columns(5)
        for column, (category, details) in zip(category_columns, CATEGORY_DATA.items()):
            with column:
                if render_category_card(category, details):
                    st.session_state.selected_category = category
                    st.session_state.page = "subcategories"
                    st.rerun()
        st.divider()
        st.subheader(ui["not_sure"])
        st.write("Explore a category directly, or use the personal match above for a recommendation made around you.")
        return

    if page == "subcategories":
        category = st.session_state.selected_category
        details = CATEGORY_DATA[category]
        st.markdown(f'<div class="eyebrow">EXPLORE · {category.upper()}</div>', unsafe_allow_html=True)
        st.title(f"{category} communities")
        st.write(details["description"])
        columns = st.columns(min(3, len(details["items"])))
        for column, (name, item) in zip(columns, details["items"].items()):
            with column:
                if render_subcategory_card(category, name, item):
                    st.session_state.selected_item = name
                    st.session_state.page = "guide"
                    st.rerun()
        if st.button(f"{ui['back']} to categories"):
            st.session_state.page = "landing"
            st.rerun()
        return

    if page == "guide":
        category = st.session_state.selected_category
        name = st.session_state.selected_item
        item = CATEGORY_DATA[category]["items"][name]
        st.markdown(f'<div class="eyebrow">{category.upper()} · COMMUNITY GUIDE</div>', unsafe_allow_html=True)
        st.title(name)
        st.image(item["image"], use_container_width=True)
        st.write(item["description"])
        render_guide(item)
        st.divider()
        if st.button(ui["ai"], type="primary"):
            st.session_state.ai_query = item["query"]
            st.session_state.page = "form"
            st.rerun()
        if st.button(f"{ui['back']} to subcategories"):
            st.session_state.page = "subcategories"
            st.rerun()
        return

    if page == "form":
        st.markdown('<div class="eyebrow">PERSONAL COMMUNITY MATCH</div>', unsafe_allow_html=True)
        st.title(ui["form_title"])
        st.write("A few details help the AI find more relevant clubs, groups, and activities.")
        with st.form("recommendation_form"):
            interest = st.text_input(ui["interest"], value=st.session_state.get("ai_query", ""), placeholder="For example: beginner football near the city centre")
            age = st.selectbox("Age group", list(AGE_OPTIONS))
            language = st.selectbox("Preferred language", ["English", "Dutch", "Spanish", "Arabic", "Other"])
            area = st.selectbox("Area", ["Anywhere in The Hague", "City Centre", "Scheveningen", "Laak", "Escamp", "Haagse Hout", "Segbroek", "Loosduinen"])
            submit = st.form_submit_button(ui["find"], type="primary")
        if not submit:
            return
        if not interest.strip():
            st.warning("Please add an interest so we can search for the right community.")
            return
        query = f"{interest.strip()} in The Hague. Age group: {age}. Preferred language: {language}. Area: {area}."
        explanation, api_error, sources = explain_matches(query, [])
        if api_error:
            st.warning("The AI search is temporarily unavailable. The guide above still gives you a safe starting point.")
        else:
            st.success(ui["suggestions"])
            st.write(explanation)
            if sources:
                st.subheader(ui["links_explore"])
                for source in sources[:8]:
                    st.markdown(f"- [{source['title']}]({source['uri']})")
        if st.button("Back home"):
            st.session_state.page = "landing"
            st.rerun()


if __name__ == "__main__":
    main()
